# Contributing Guide

This Contributing Guide is depend on ["hxhS (hugoalh & hugoalh Studio) Universal Contributing Guide"](https://github.com/hugoalh/hugoalh/blob/main/universal-guide/contributing.md), along with revise and take precedence over it.

## Revise

*N/A*
